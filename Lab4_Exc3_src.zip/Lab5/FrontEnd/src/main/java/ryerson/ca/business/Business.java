package ryerson.ca.business;

import java.io.IOException;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import ryerson.ca.helper.ItemXML;

public class Business {

    public static boolean isAuthenticated(String username, String password) {
        // Implement your authentication logic here.
        // For example, checking against a database or an authentication service.
        return username.equals("test") && password.equals("password");
    }

    public static ItemXML getServices(String query, String token) throws IOException {
        Client client = ClientBuilder.newClient();
        WebTarget target = client.target("http://localhost:8080")
                .path("items")
                .queryParam("query", query);

        Invocation.Builder invocationBuilder = target.request(MediaType.APPLICATION_XML);
        
        if (token != null) {
            invocationBuilder.header("Authorization", "Bearer " + token);
        }

        Response response = invocationBuilder.get();

        if (response.getStatus() == 200) {
            return response.readEntity(ItemXML.class);
        } else {
            // Handle error responses accordingly.
            throw new IOException("Error response from backend: " + response.getStatus());
        }
    }

    public static boolean holdItem(int itemId, String token) throws IOException {
        Client client = ClientBuilder.newClient();
        WebTarget target = client.target("http://localhost:8080")
                .path("items")
                .path(String.valueOf(itemId))
                .path("hold");

        Invocation.Builder invocationBuilder = target.request();

        if (token != null) {
            invocationBuilder.header("Authorization", "Bearer " + token);
        }

        Response response = invocationBuilder.post(null);

        return response.getStatus() == 200;
    }
}
